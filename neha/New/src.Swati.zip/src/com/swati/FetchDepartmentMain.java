package com.swati;

import java.sql.*;
import java.util.LinkedList;

public class FetchDepartmentMain {

    public static void main(String[] args) {

        Connection con = null;
        Statement st = null;
        ResultSet rs = null;

        LinkedList<Department> resultlist = new LinkedList<>();

        //Step 1: Load JDBC Driver
        try{
            Class.forName("oracle.jdbc.OracleDriver");
            System.out.println("JDBC Driver found and Loaded!");
        }catch(ClassNotFoundException ce){
            System.out.println("Cannot load driver "+ce.getMessage());
            return; //Close main method
        }

        //Step 2: Create a connection
        try{
            con = DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521/orcl","hr","hr");
            System.out.println("Connected to DB");
        }catch(SQLException ex){
            System.out.println("Unable to connect: "+ex.getMessage());
            return;
        }

        //Step 3: Create Statement
        try {
            st = con.createStatement();
            System.out.println("Statement created!");
        }catch(SQLException ex){
            System.out.println("Unable to create a statement! "+ex.getMessage());
        }
        //Step 4: Execute the statement
        try{
            rs = st.executeQuery("SELECT * FROM departments where department_id = '30'");
            while(rs.next()){
                int deptit = rs.getInt("department_id");
                String deptname = rs.getString("department_name");
                int mngid = rs.getInt("manager_id");
                int locationid = rs.getInt("location_id");

                Department deptlist = new Department(deptit, deptname, mngid, locationid);
                resultlist.add(deptlist);
                System.out.println(resultlist);
            }
            System.out.println("Fetched some data!");
        }catch(SQLException ex){
            System.out.println("Unable to fetch the data ! "+ex.getMessage());
        }
        //Step 6: Close Connection
        try{
            //close everything
            rs.close();
            st.close();
            con.close();
            System.out.println("Closed everything!");
        }catch(SQLException ex){
            System.out.println("Error while closing the connection "+ex.getMessage());
        }
    }
}
