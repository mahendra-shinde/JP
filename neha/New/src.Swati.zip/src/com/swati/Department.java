package com.swati;

public class Department {

    private int departmentid;
    private String departmentname;
    private int managerid;
    private int locationid;

    public Department(int departmentid, String departmentname, int managerid, int locationid) {
        this.departmentid = departmentid;
        this.departmentname = departmentname;
        this.managerid = managerid;
        this.locationid = locationid;
    }

    public int getDepartmentid() {
        return departmentid;
    }

    public void setDepartmentid(int departmentid) {
        this.departmentid = departmentid;
    }

    public String getDepartmentname() {
        return departmentname;
    }

    public void setDepartmentname(String departmentname) {
        this.departmentname = departmentname;
    }

    public int getManagerid() {
        return managerid;
    }

    public void setManagerid(int managerid) {
        this.managerid = managerid;
    }

    public int getLocationid() {
        return locationid;
    }

    public void setLocationid(int locationid) {
        this.locationid = locationid;
    }

    @Override
    public String toString() {
        return "Department{" +
                "departmentid=" + departmentid +
                ", departmentname='" + departmentname + '\'' +
                ", managerid=" + managerid +
                ", locationid=" + locationid +
                '}';
    }
}
