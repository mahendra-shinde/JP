package com.swati;

import org.junit.*;
import static org.junit.Assert.*;
import java.util.*;
public class SalaryCalculatorTest extends Throwable{

    SalaryCalculator sc = null;

    //private int TAX_FREE = 300000;
    private int salary = 350000;
    private double tax_rate = 0.085;

    @Test
    public void testCalcTax() {
        sc = new SalaryCalculator();
    double tax = sc.calcTax(salary, tax_rate);
    assertEquals(4250, tax,0.1 );

    }
}
