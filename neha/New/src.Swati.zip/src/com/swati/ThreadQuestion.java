package com.swati;

import java.util.*;

public class ThreadQuestion implements Runnable {

    private String currentdate;
    //Date date = new Date();

    @Override
    public void run() {
        try {
            while(true)
            {
                /*currentdate = date.toString();
                System.out.println(currentdate);*/
                Calendar now = Calendar.getInstance();
                System.out.println(now.getTime());
                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


}
