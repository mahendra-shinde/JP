package com.swati;

public class ThreadMain {

    public static void main(String[] args) {
        // Initializing an object of class Thread
        ThreadQuestion currentdate1 = new ThreadQuestion();

        //Creating a thread
        Thread t1 = new Thread(currentdate1);

        //Starting a Thread
        t1.start();
        try {
            System.out.println("Current Date and time is: ");
            t1.join();
        } catch (InterruptedException ex) {
            ex.printStackTrace();

        }
    }
}
