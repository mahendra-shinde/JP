package com.arpita;

import java.util.*;

public class Main {

    public static void main(String[] args) {

        /*Question 2:- Getting User Name and Password using Scanner Class and
        Validating the same against the rules defined in question2. User Name and Password
         */

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter your username : ");
        String username = sc.nextLine();

        UserName un = new UserName();

        
            try {
                un.checkUserName(username);

            } catch (IllegalCredentialException ex) {
                System.out.println("Please check UerName. Length should be between 6 and 12 and should not contain space - " + ex);

            }


        System.out.println("Enter your password : ");
        String password = sc.nextLine();

        Password ps = new Password();

        try {
            ps.checkPassword(password);

        } catch (IllegalCredentialException ex) {
            System.out.println("Please check Password. It should be more than 8 chars - " + ex);

        }

        //Question 4: Displaying the list defined in UserManager Class//
        UserManager usmgr = new UserManager ();
        usmgr.usermanagerlist();

    }
}

