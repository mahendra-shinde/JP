package com.arpita;

import sun.security.util.Length;

public class Password extends IllegalCredentialException {

    public void checkPassword(String password) throws IllegalCredentialException {


        int passlen = password.length();


        if (passlen >= 8) {


            //System.out.println("Passsword is 8 char long");


        } else throw new IllegalCredentialException();


    }
}








