package com.arpita;

import sun.security.util.Length;

public class UserName extends IllegalCredentialException {

    public void checkUserName(String username) throws IllegalCredentialException {



        int userlen = username.length();


        if (userlen >= 6 && userlen <= 12) {

            //System.out.println(userlen);

            //System.out.println("User Name is greater than 6 and less than 12");
            if (username.contains(" ")) {

                throw new IllegalCredentialException();


            }
            //System.out.println("User Name does contain space");


        } else throw new IllegalCredentialException();


    }
}








