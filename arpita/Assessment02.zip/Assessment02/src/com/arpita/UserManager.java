package com.arpita;

import java.util.*;
import java.lang.*;

public class UserManager {

    public void usermanagerlist() {


        List usermanager = new ArrayList();

        usermanager.add(new User("Ashsih", "pass@12245", "Admin", true));

        usermanager.add(new User("Anish", "My$pass123", "User", true));

        usermanager.add(new User("Alok", "$$xyz$$12345", "User", true));

        usermanager.add(new User("Aditi", "Opps_forgot_1", "Userge", true));


        for (Object obj : usermanager) {
            System.out.println("List defined in User Manager Class..." + obj);
        }
    }


    //Question 4- Implementing add method

    public void add() {

        System.out.println("Adding usermanager list");

    }


    //Question 4- Implementing find method

    public String find() {

        String username = "";

        System.out.println("Finding users from usermanager list");

        return username;
    }


    //Question 4- Implementing getUsers method

    public String getUsers() {

        String list ="";

        System.out.println("Get list of Users");

        return list;
    }



}