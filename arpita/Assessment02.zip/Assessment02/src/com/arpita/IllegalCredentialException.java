package com.arpita;

public class IllegalCredentialException extends Exception {

// Question 1: User Defined Unchecked Exception

    IllegalCredentialException () {
        super ("Illegal Credential Exception");
    }


}
